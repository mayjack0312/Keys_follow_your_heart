﻿Pro případy, kdy se aplikace používá v prostředí hybridní reality, zahrňte 3D spouštěč aplikace.

Vygenerovaný prostředek je potřeba nahradit prostředkem, který je vhodný pro vaši aplikaci. Další informace najdete na webu [docs.microsoft.com](https://docs.microsoft.com/windows/mixed-reality/3d-app-launcher-design-guidance).
