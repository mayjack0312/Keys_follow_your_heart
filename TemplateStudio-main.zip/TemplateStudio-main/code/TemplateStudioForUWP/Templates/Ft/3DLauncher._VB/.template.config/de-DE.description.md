﻿Nehmen Sie ein 3D-App-Startprogramm auf für den Fall, dass die App in einer Mixed Reality-Umgebung verwendet wird.

Die erstellte Ressource sollte durch eine für Ihre App geeignete Ressource ersetzt werden. Weitere Details finden Sie unter [docs.microsoft.com](https://docs.microsoft.com/windows/mixed-reality/3d-app-launcher-design-guidance).
