﻿Include a 3D app launcher for when the app is used in a Mixed Reality environment.

The generated asset should be replaced with one appropriate to your app. For more details see [docs.microsoft.com](https://docs.microsoft.com/windows/mixed-reality/3d-app-launcher-design-guidance).
