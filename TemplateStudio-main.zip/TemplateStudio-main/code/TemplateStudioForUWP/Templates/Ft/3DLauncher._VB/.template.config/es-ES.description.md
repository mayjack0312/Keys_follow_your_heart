﻿Incluye un iniciador de aplicaciones 3D para las ocasiones en que la aplicación se utilice en un entorno Realidad mixta.

El activo generado debe sustituirse por otro adecuado para su aplicación. Para obtener información más detallada, consulte [docs.microsoft.com](https://docs.microsoft.com/windows/mixed-reality/3d-app-launcher-design-guidance).
