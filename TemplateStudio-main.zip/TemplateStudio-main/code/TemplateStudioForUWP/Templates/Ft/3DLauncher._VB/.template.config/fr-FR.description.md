﻿Inclut un lanceur d'applications 3D lorsque l'application est utilisée dans un environnement de réalité mixte.

L'actif généré doit être remplacé par un actif approprié à votre application. Pour en savoir plus, consultez [docs.microsoft.com](https://docs.microsoft.com/windows/mixed-reality/3d-app-launcher-design-guidance).
