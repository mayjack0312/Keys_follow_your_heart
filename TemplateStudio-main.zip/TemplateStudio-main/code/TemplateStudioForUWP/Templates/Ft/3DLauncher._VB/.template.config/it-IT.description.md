﻿Include l'avvio dell'app 3D per quando l'app è utilizzata in un ambiente di realtà mista.

L'asset generato deve essere sostituito con uno adeguato alla tua app. Per maggiori informazioni consulta [docs.microsoft.com](https://docs.microsoft.com/windows/mixed-reality/3d-app-launcher-design-guidance).
