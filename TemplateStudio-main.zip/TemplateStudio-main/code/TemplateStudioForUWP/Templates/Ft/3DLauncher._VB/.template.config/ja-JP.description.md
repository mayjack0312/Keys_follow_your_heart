﻿アプリが Mixed Reality 環境で使用されるときの 3D アプリ ランチャーを含む。

生成されたアセットは、アプリに適したアセットに変更する必要があります。詳細については以下をご確認ください [docs.microsoft.com](https://docs.microsoft.com/windows/mixed-reality/3d-app-launcher-design-guidance)。
