﻿혼합 현실 환경에서 앱을 사용하는 경우 3D 앱 시작 관리자가 포함됩니다.

생성된 자산은 앱에 적합한 것으로 교체해야 합니다. 자세한 내용은 [docs.microsoft.com](https://docs.microsoft.com/windows/mixed-reality/3d-app-launcher-design-guidance)에서 알아보십시오.
