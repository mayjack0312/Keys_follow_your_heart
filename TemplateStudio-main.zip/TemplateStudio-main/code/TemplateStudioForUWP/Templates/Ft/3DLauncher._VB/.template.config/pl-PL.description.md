﻿Dołącz narzędzie do uruchamiania aplikacji 3D w przypadku, gdy aplikacja jest używana w środowisku rzeczywistości mieszanej.

Wygenerowany element zawartości należy zastąpić takim, który jest odpowiedni dla Twojej aplikacji. Więcej szczegółów można znaleźć na stronie [docs.microsoft.com](https://docs.microsoft.com/pl-pl/windows/mixed-reality/3d-app-launcher-design-guidance).
