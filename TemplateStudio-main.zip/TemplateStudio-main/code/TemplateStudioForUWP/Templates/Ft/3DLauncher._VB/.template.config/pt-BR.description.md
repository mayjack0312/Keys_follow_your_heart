﻿Inclua um inicializador de aplicativos 3D para quando o aplicativo for usado em um ambiente de Realidade Misturada.

O recurso gerado deve ser substituído por um adequado ao seu aplicativo. Para obter mais detalhes, confira [docs.microsoft.com](https://docs.microsoft.com/windows/mixed-reality/3d-app-launcher-design-guidance).
