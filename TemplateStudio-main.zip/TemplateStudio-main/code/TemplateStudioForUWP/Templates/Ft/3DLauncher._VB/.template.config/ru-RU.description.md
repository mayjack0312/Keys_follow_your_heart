﻿Включите средство запуска 3D-приложений для использования приложений в среде смешанной реальности.

Созданный ресурс следует заменить подходящим для вашего приложения. Дополнительные сведения: [docs.microsoft.com](https://docs.microsoft.com/ru-ru/windows/mixed-reality/3d-app-launcher-design-guidance).
