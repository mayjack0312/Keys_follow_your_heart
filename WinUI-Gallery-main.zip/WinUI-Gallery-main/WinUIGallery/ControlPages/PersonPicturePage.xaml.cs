﻿using Microsoft.UI.Xaml.Controls;

namespace AppUIBasics.ControlPages
{
    public sealed partial class PersonPicturePage : Page
    {
        public PersonPicturePage()
        {
            this.InitializeComponent();
        }
    }
}
