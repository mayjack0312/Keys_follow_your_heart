// Copyright (c) Microsoft Corporation and Contributors.
// Licensed under the MIT License.

using Microsoft.UI.Xaml.Controls;

namespace WinUIGallery.DesktopWap.Controls.DesignGuidance.ColorSections
{
    public sealed partial class BackgroundSection : Page
    {
        public BackgroundSection()
        {
            this.InitializeComponent();
        }
    }
}
