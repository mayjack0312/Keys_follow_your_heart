using Microsoft.UI.Xaml.Controls;

namespace AppUIBasics.SamplePages
{
    public sealed partial class SamplePage5 : Page
    {
        public SamplePage5()
        {
            this.InitializeComponent();
        }
    }
}
