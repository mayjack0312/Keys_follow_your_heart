using Microsoft.UI.Xaml.Controls;

namespace AppUIBasics.SamplePages
{
    public sealed partial class SamplePage6 : Page
    {
        public SamplePage6()
        {
            this.InitializeComponent();
        }
    }
}
