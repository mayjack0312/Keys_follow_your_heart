using Microsoft.UI.Xaml.Controls;

namespace AppUIBasics.SamplePages
{
    public sealed partial class SamplePage7 : Page
    {
        public SamplePage7()
        {
            this.InitializeComponent();
        }
    }
}
